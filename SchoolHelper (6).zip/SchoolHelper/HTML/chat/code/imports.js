import {
  LoadNav
} from "/JS/classes.js"

LoadNav();
