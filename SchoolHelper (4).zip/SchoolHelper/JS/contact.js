import {
  LoadNav
} from "./classes.js"

LoadNav();
