import {LoadNav, Load} from "./classes.js";

LoadNav();
Load();
